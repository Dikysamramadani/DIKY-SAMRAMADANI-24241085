 # a = 10  - tipe data integer

# tipe data integer, angka satuan yang tidak punya koma
data_integer = 11
print("data = ", data_integer)
print("tipe data = ", type(data_integer))

# type () adalah fungsi cek tipe data variabel

# tipe data float, angka satuan yang punya koma

data_float = 3.14
print("data = ", data_float)
print("tipe data = ", type(data_float))

# tipe data string, untuk kumpulan karakter
data_string = 'universitas pendidikan mandalika'
print("data = ", data_string)
print("tipe data = ", type(data_string))
