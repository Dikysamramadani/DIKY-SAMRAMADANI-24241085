# Casting = mengubah tipe data sebuah variabel
# jika punya a = ink di ubah menjadi float, str, bool

# INTEGER
print("===INTEGER===")
data_int = 222
print("data = ", data_int, "type = ", type(data_int))

# ubah int ke float
data_float = float(data_int)

#ubah int ke str
data_str = str(data_int)
# ubah int ke bool
data_bool = bool(data_int)
# Cetak
print("data = ", data_float, "type = ", type(data_float))
print("data = ", data_str, "type = ", type(data_str))
print("data = ", data_bool, "type = ", type(data_bool))

# FLOAT
print("===FLOAT===")
data_float = 222.0
print("data = ", data_float, "type = ", type(data_float))

# ubah float ke int
data_float = int(data_float)

#ubah float ke str
data_float = str(data_float)
# ubah float ke bool
data_float = bool(data_float)
# Cetak
print("data = ", data_int, "type = ", type(data_int))
print("data = ", data_str, "type = ", type(data_str))
print("data = ", data_bool, "type = ", type(data_bool))
