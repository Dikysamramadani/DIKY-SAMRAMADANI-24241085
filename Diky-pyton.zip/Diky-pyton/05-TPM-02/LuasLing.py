import math

# input jari-jari lingkran 
radius = float (input("masukkan jari-jari lingkaran: "))

# Hitung luas lingkaran 
area = math.pi * radius ** 2 

 # Tampilkan hasilnya 
print(f"Luas lingkaran dengan jari-jari {radius} adalah {area}")
