# input suhu dalam fahrenheit 
fahrenheit = float(input("masukkan suhu dalam fahrenheit: "))
                         
# konversi ke celsius
celcius = (5/9) * (fahrenheit - 32)

# Tampilkan hasilnya 
print(f"{fahrenheit} fahrenheit sama dengan {celcius} celsius")

